import { lazy } from 'react';

// project imports
import MainLayout from 'layout/MainLayout';
import Loadable from 'ui-component/Loadable';
import Home from 'views/pages/Home';
import ProfileVerification from 'views/pages/ProfileVerification';

// dashboard routing
const DashboardDefault = Loadable(lazy(() => import('views/dashboard/Default')));

// utilities routing
const UtilsTypography = Loadable(lazy(() => import('views/utilities/Typography')));
const UtilsColor = Loadable(lazy(() => import('views/utilities/Color')));
const UtilsShadow = Loadable(lazy(() => import('views/utilities/Shadow')));
const UtilsMaterialIcons = Loadable(lazy(() => import('views/utilities/MaterialIcons')));
const UtilsTablerIcons = Loadable(lazy(() => import('views/utilities/TablerIcons')));

// sample page routing
const SamplePage = Loadable(lazy(() => import('views/sample-page')));

// ==============================|| MAIN ROUTING ||============================== //

const MainRoutes = {
    path: '/Profile',
    element: <MainLayout />,
    children: [
        {
            path: '/Profile',
            element: <DashboardDefault/>
        },
        {
            path: '/Profile',
            children: [
                {
                    path: 'profile',
                    element: <DashboardDefault />
                }
            ]
        },
        {
            path: 'utils',
            children: [
                {
                    path: 'employee-registration',
                    element: <ProfileVerification />
                }
            ]
        },
        {
            path: 'utils',
            children: [
                {
                    path: 'update-transfer',
                    element: <UtilsColor />
                }
            ]
        },
        {
            path: 'utils',
            children: [
                {
                    path: 'update-promotion',
                    element: <UtilsShadow />
                }
            ]
        },
        {
            path: 'utils',
            children: [
                {
                    path: 'apply-for-exams',
                    element: <UtilsTablerIcons />
                }
            ]
        },
        {
            path: 'utils',
            children: [
                {
                    path: 'view-applied-exams',
                    element: <UtilsMaterialIcons />
                }
            ]
        },
        {
            path: 'utils',
            children: [
                {
                    path: 'view-profile',
                    element: <UtilsMaterialIcons />
                }
            ]
        },
       
    ]
};

export default MainRoutes;
