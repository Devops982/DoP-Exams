// assets
import { IconTypography, IconPalette, IconShadow, IconWindmill } from '@tabler/icons';
import HowToRegIcon from '@mui/icons-material/HowToReg';
import TransferWithinAStationIcon from '@mui/icons-material/TransferWithinAStation';
import WorkOutlineIcon from '@mui/icons-material/WorkOutline';
import CreateIcon from '@mui/icons-material/Create';
import PreviewIcon from '@mui/icons-material/Preview';
// constant
const icons = {
    IconTypography,
    IconPalette,
    IconShadow,
    IconWindmill,
    HowToRegIcon,
    TransferWithinAStationIcon,
    WorkOutlineIcon,
    CreateIcon,
    PreviewIcon,
};

// ==============================|| UTILITIES MENU ITEMS ||============================== //

const utilities = {
    id: 'utilities',
    // title: 'Utilities',
    type: 'group',
    children: [
        {
            id: 'Employee-Registration',
            title: 'Employee Registration',
            type: 'item',
            url: '/profile/utils/employee-registration',
            icon: icons.HowToRegIcon,
            breadcrumbs: false
        },
        {
            id: 'update-transfer',
            title: 'Update Transfer',
            type: 'item',
            url: '/profile/utils/update-transfer',
            icon: icons.TransferWithinAStationIcon,
            breadcrumbs: false
        },
        {
            id: 'update-promotion',
            title: 'Update Promotion',
            type: 'item',
            url: '/profile/utils/update-promotion',
            icon: icons.WorkOutlineIcon,
            breadcrumbs: false
        },
        {
            id: 'apply-for-exams',
            title: 'Apply For Exams',
            type: 'item',
            url: '/profile/utils/apply-for-exams',
            icon: icons.CreateIcon,
            breadcrumbs: false
        },
        {
            id: 'view-applied-exams',
            title: 'View Applied Exams',
            type: 'item',
            url: '/profile/utils/view-applied-exams',
            icon: icons.IconShadow,
            breadcrumbs: false
        },
        {
            id: 'view-profile',
            title: 'View Profile',
            type: 'item',
            url: '/profile/utils/view-profile',
            icon: icons.PreviewIcon,
            breadcrumbs: false
        },
       
    ]
};

export default utilities;
